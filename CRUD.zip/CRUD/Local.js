class Local{
	Direcccion="UNIVERSIDAD POLITECNICA DE TECAMAC"
    Horarios="07:00----14:00";

	constructor(direccion, horarios){
		this.Direcccion=direccion;
		this.Horarios=horarios;
	}
}
